var __wpo = {
  "assets": {
    "main": [
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/e73aa0301c9b5da2ec762c83d7d7b6b4.png",
      "/fb76686a848ef3221a6d6ec4b5e569c1.jpg",
      "/523fa703329930b82a089c82cca53d71.jpg",
      "/ced611daf7709cc778da928fec876475.eot",
      "/96db6f3e643980be0b73bd3795494e6a.jpg",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/0f0072ced9d946c89515d3f179b03cae.png",
      "/55b148651a8a13fb917e7bb32a67ac9b.png",
      "/872c5a3f69ff1a088b07f2d20f251e90.jpg",
      "/7220c7b585c3d20da67a49792b938d39.png",
      "/c09211a5f94cd00aa7676a5585da6532.jpg",
      "/02a9e69d179ed3ea9e24f42ba83caf1d.png",
      "/f1052ca178963f8bc1b97263190818bc.png",
      "/07d3fa10dac3c565a78ca03097a9d58a.jpg",
      "/bc3a33a200b601d3c004802fba46bf72.jpg",
      "/9d506cb49392703faec7ef617115f062.png",
      "/98f338fc9f3b51284613477040cb4962.jpg",
      "/1ba48a04ce8570dbbaedf3cc95881153.png",
      "/245ddb491166b1de8306c84ff48c230d.png",
      "/4fb2fd9cfa6b2f5542a2feaed9016916.png",
      "/01dd55a05dad6a7f040e8ffc1298a08e.jpg",
      "/2a50f34f4668d3db18275986e797c061.png",
      "/6b50097f39b531164935a7ca5368abe3.jpg",
      "/c8ebca010690331c8adf5daafc762873.png",
      "/caf9aab5ca9d624da98b035e0b712d81.png",
      "/0c74f0e0eabbf424dd6fca3bf362af4b.png",
      "/5bbf5547eeea5b4dd430630098ccf964.jpg",
      "/3fbf6ec5fa647bb1438f9b8683cab45b.png",
      "/favicon.ico",
      "/a55730fd6be8ea3d229daa95f5c25e15.png",
      "/6bb9d2be55a1da45180f8e4b90a7ee4b.png",
      "/575f451bacd4b321b0a2872664bb4488.png",
      "/f96ac75f103e13420852396e1cecf064.png",
      "/ebe5d78a92cb77c0b9d0d8c1fec1e818.png",
      "/58395ec2ee9571f5a7ec5bea36c9f37f.jpg",
      "/ec683e2ce710c077e231e4d95550f745.png",
      "/974fee8ac2b5e4357566db94cc21c6ea.png",
      "/471136f47c1f21b7a3b3212ca5120d8b.jpg",
      "/d22820f231adf885e2c33c54663d661e.jpg",
      "/037c1385efd4c78a4d76890f94a17f0e.png",
      "/runtime.5c17aff04c5414c95288.js",
      "/"
    ],
    "additional": [
      "/npm.material-ui.d977be12f5814593e507.chunk.js",
      "/npm.redux-saga.b46333f6d3d7b015162c.chunk.js",
      "/npm.webpack.68b1cf86149741bfe920.chunk.js",
      "/npm.immutable.160fa7a8fce8bcbd4829.chunk.js",
      "/npm.lodash.48317a129b2ff9e4e292.chunk.js",
      "/npm.intl.bccfaa29b51f45d8a373.chunk.js",
      "/main.8d2b0ec2e1f4cdc4d26b.chunk.js",
      "/npm.babel.066e5ffa115d3d67d9fd.chunk.js",
      "/npm.d3-array.758d27a2a73f0300aacd.chunk.js",
      "/npm.d3-axis.f3eb73d4c83416c29d3e.chunk.js",
      "/npm.d3-brush.80ed73b0ab7bd2811957.chunk.js",
      "/npm.d3-chord.c473912e7275a63b26f4.chunk.js",
      "/npm.debug.b130822c0697a62b4610.chunk.js",
      "/npm.jsonp.173bef81fbcd7cbc9f89.chunk.js",
      "/npm.lodash.orderby.a6470a34379e5024bafd.chunk.js",
      "/npm.mapbox-gl.a7191c296644920783ac.chunk.js",
      "/npm.ms.4a75acef9959405597f6.chunk.js",
      "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
      "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
      "/npm.react-share.60585d3e13c2b4a2a37b.chunk.js",
      "/npm.react-slick.e0cc7132c7c24c8992a2.chunk.js",
      "/npm.react-transition-group.0be86cfee6a3f30564c2.chunk.js",
      "/npm.slick-carousel.8152ea1ed6b72ab24a2a.chunk.js",
      "/24.f87e5d3864422478be3c.chunk.js",
      "/25.6f118f43c8f3c7cc31f4.chunk.js",
      "/26.b1d279e2a2de7c2822f5.chunk.js",
      "/27.42204162e494299dea17.chunk.js",
      "/28.41d58c054cdf6ac30c62.chunk.js",
      "/29.b0225544b1ee4935f5a5.chunk.js",
      "/30.b0229c47695f74a841d1.chunk.js",
      "/31.189e3c8e7d7a60bd03b6.chunk.js",
      "/32.5cc91ad33ed9413fa4a5.chunk.js",
      "/33.d4dee0db0d93a25508bb.chunk.js",
      "/34.2ac416d6d7ea6fd97029.chunk.js",
      "/35.e5ec92b078d10900a029.chunk.js",
      "/36.7521309cf2f6dd42d0e5.chunk.js",
      "/37.e04f57a30078e432bac9.chunk.js",
      "/38.1fb6092b05583d4316ad.chunk.js",
      "/39.4836059101009f2fc949.chunk.js",
      "/40.c5cdfcb3bdeb3defd021.chunk.js",
      "/41.7e7e4f7f7198e9b4bd12.chunk.js",
      "/42.34e0b4a3840bf695734b.chunk.js",
      "/43.49188a710da07271b797.chunk.js",
      "/44.eed71e6b8fb825932b23.chunk.js",
      "/45.ad557d5659c581bd1806.chunk.js",
      "/46.a9e5d1cba81ba06bb12d.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "72c274ede199fc1424e289c4af278c1ac7813cab": "/e73aa0301c9b5da2ec762c83d7d7b6b4.png",
    "96390d1fc8f6d30b59217e013ca0a0ce1fd85c2e": "/fb76686a848ef3221a6d6ec4b5e569c1.jpg",
    "9315778c46e671fc68a29919786f1b2805a91085": "/523fa703329930b82a089c82cca53d71.jpg",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "897d0b2e6487cb5c843356e95ac162330fdb1ed6": "/96db6f3e643980be0b73bd3795494e6a.jpg",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "28beb1256874194460fac68ef32d956397f603c8": "/0f0072ced9d946c89515d3f179b03cae.png",
    "26eabd6df62a9dabe0b3ef804483a1c24abd03ee": "/55b148651a8a13fb917e7bb32a67ac9b.png",
    "2c5bb64ca4710176203ca4fdda7b1af6137aa618": "/872c5a3f69ff1a088b07f2d20f251e90.jpg",
    "ff419ba705c031a8c3df9663115934ce600f02a1": "/7220c7b585c3d20da67a49792b938d39.png",
    "0f3ded3bc7b57e094c0aef6c519c2d7744d6bb76": "/c09211a5f94cd00aa7676a5585da6532.jpg",
    "9557c18913a9b6c6bc2204a0eeb209338f6373a4": "/02a9e69d179ed3ea9e24f42ba83caf1d.png",
    "486dba84bb0b1e2a43f58bb14546ec5500888b46": "/f1052ca178963f8bc1b97263190818bc.png",
    "aa0a1b1ccf297ab5b214cd5f8f07e64c97791004": "/07d3fa10dac3c565a78ca03097a9d58a.jpg",
    "dfe3da147eee31e5ddcce7a0a5ad00657b072dc9": "/bc3a33a200b601d3c004802fba46bf72.jpg",
    "da66a25a76a1cecc51fdf034534cc63a45932c81": "/9d506cb49392703faec7ef617115f062.png",
    "7be484841fdff137c98ca672d3a353b8d7ff29b8": "/98f338fc9f3b51284613477040cb4962.jpg",
    "45be8c434601e6c3f426f6560f63a5f629ed5cb3": "/1ba48a04ce8570dbbaedf3cc95881153.png",
    "778aa249b3c90e1b2d79a9e1162f856289b74f18": "/245ddb491166b1de8306c84ff48c230d.png",
    "c5971bc996ce994b6eea4bee02cf66f267b4531b": "/4fb2fd9cfa6b2f5542a2feaed9016916.png",
    "1ebe17e8e71723d1ab5727e28107ebd951e884ba": "/01dd55a05dad6a7f040e8ffc1298a08e.jpg",
    "7b0e41c380c3adcefacc862c32f712eea655e9e9": "/2a50f34f4668d3db18275986e797c061.png",
    "c7f6767c7145a8c0392a8eca2ebfcf1e0484f3b7": "/6b50097f39b531164935a7ca5368abe3.jpg",
    "cceff317f3d509ef601b1f2e3690894c051ced71": "/c8ebca010690331c8adf5daafc762873.png",
    "19a9bf439d62738f3a779153fddd9bf4152e95f1": "/caf9aab5ca9d624da98b035e0b712d81.png",
    "00131703acb0186c87132999d2ad9289e386b321": "/0c74f0e0eabbf424dd6fca3bf362af4b.png",
    "9e56c7fc2e1cff2d4f80d27878caba85699171bf": "/5bbf5547eeea5b4dd430630098ccf964.jpg",
    "8751d5140a631bb2f952a6b9ed04b77055d553e7": "/3fbf6ec5fa647bb1438f9b8683cab45b.png",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "14411c502c11705abb5165106db015cd8bc8b259": "/a55730fd6be8ea3d229daa95f5c25e15.png",
    "0f49c7386c363775a3ca866703f3b6ead65413a5": "/6bb9d2be55a1da45180f8e4b90a7ee4b.png",
    "05d1cabc482b77b68bb46efda6346f67cb8e15aa": "/575f451bacd4b321b0a2872664bb4488.png",
    "8c156d2c4d811b234b2443e36b370991e1c87227": "/f96ac75f103e13420852396e1cecf064.png",
    "8376893b14c3e4569725c66c256940b4bda328df": "/ebe5d78a92cb77c0b9d0d8c1fec1e818.png",
    "e5bb81e58e99fc6230124bcbfcb6973fa2563b4c": "/58395ec2ee9571f5a7ec5bea36c9f37f.jpg",
    "d9f9d11657fad053f8c8e452b012e8afa9273686": "/ec683e2ce710c077e231e4d95550f745.png",
    "e5e6731dd6da2f8bf654454d73a90904ba1e1061": "/974fee8ac2b5e4357566db94cc21c6ea.png",
    "b8b4742dddd36ef76195602fe38e16f6df3cb9b2": "/471136f47c1f21b7a3b3212ca5120d8b.jpg",
    "1f146b49326b5f68c2e75784f50c252cb3c579c1": "/d22820f231adf885e2c33c54663d661e.jpg",
    "aae3ba5eafec936c22f18d7aaed2e26093f1edce": "/037c1385efd4c78a4d76890f94a17f0e.png",
    "16db5de694964fac2cea7e9824d03565f67cefa1": "/npm.material-ui.d977be12f5814593e507.chunk.js",
    "8216a0a2c0e68898398fb506c6bd0b825a10cebf": "/npm.redux-saga.b46333f6d3d7b015162c.chunk.js",
    "a32b8c4d069544d3731ecbfedfcdba7bb465e691": "/npm.webpack.68b1cf86149741bfe920.chunk.js",
    "5d39b0f32c03862f443eb7f2e7e532e602201db4": "/npm.immutable.160fa7a8fce8bcbd4829.chunk.js",
    "fdda2c2b7493db53705a373be9a57c3d45bd8887": "/npm.lodash.48317a129b2ff9e4e292.chunk.js",
    "5ab7af351971bac84b1fa27c609789441af184ab": "/npm.intl.bccfaa29b51f45d8a373.chunk.js",
    "f4a5d9bcc4eeb639662d4ae2ebf91e326ce74ee2": "/main.8d2b0ec2e1f4cdc4d26b.chunk.js",
    "c778f65d54d8c72774b17cb126a3714a93c9005f": "/npm.babel.066e5ffa115d3d67d9fd.chunk.js",
    "b4a212dcb14c613c273cc221c819783007171bbb": "/npm.d3-array.758d27a2a73f0300aacd.chunk.js",
    "dd4043dff8d49c136870c60e77703456652b1105": "/npm.d3-axis.f3eb73d4c83416c29d3e.chunk.js",
    "da599da830a7de6074bf09a86c94db582d9941e2": "/npm.d3-brush.80ed73b0ab7bd2811957.chunk.js",
    "70c49a8b313e49b47143cb24186d1d944e5d0d6d": "/npm.d3-chord.c473912e7275a63b26f4.chunk.js",
    "896bea31f15eba53a36f1aae63438e6dd41732ff": "/npm.debug.b130822c0697a62b4610.chunk.js",
    "0c3fddceff801f10ae3a366195a47b22f39c8bd1": "/npm.jsonp.173bef81fbcd7cbc9f89.chunk.js",
    "45a7d8bc2affac496b5c7bb384421a281d80fcd6": "/npm.lodash.orderby.a6470a34379e5024bafd.chunk.js",
    "67265cb0147961982216752614df48800f89c31c": "/npm.mapbox-gl.a7191c296644920783ac.chunk.js",
    "c1d3636b5037d0c1a27c4b15f63c21562815a109": "/npm.ms.4a75acef9959405597f6.chunk.js",
    "6aa2bce4b04b5c348195ad5f80d3b482bc441b87": "/npm.react-app-polyfill.72835840dc853fc08875.chunk.js",
    "2d3d4842d3f023f40286bf66ea301ee02bf85483": "/npm.react-redux.51b23f6a7ba46798d86c.chunk.js",
    "0e32b4039fd7edbb0a6496bf2ae61519b4c840c3": "/npm.react-share.60585d3e13c2b4a2a37b.chunk.js",
    "44aa3d8182b2252bf29a0d4894bcce6d2dfdf51a": "/npm.react-slick.e0cc7132c7c24c8992a2.chunk.js",
    "2fd95e159dec0e0c2c40351d325d22eb12304441": "/npm.react-transition-group.0be86cfee6a3f30564c2.chunk.js",
    "41d5f7c27c3267147d22965776a188f8bd93e8c0": "/npm.slick-carousel.8152ea1ed6b72ab24a2a.chunk.js",
    "8c685ee892f7efbcd189b296a07af45efc425e36": "/runtime.5c17aff04c5414c95288.js",
    "27f9eac27b74ca8cfeb28721128d16cd19e42b3f": "/24.f87e5d3864422478be3c.chunk.js",
    "0eabf09d79df0befb4106b7a7b6db5d95db73e0f": "/25.6f118f43c8f3c7cc31f4.chunk.js",
    "9935af7586199e2a26c49087588323e1a24b7aac": "/26.b1d279e2a2de7c2822f5.chunk.js",
    "ff6e8190cb37b0d9d0b101ce7f9ce63b2b0fe0d8": "/27.42204162e494299dea17.chunk.js",
    "d0cdd0e74238fdd69ed7b9cca2cfa54a3e488878": "/28.41d58c054cdf6ac30c62.chunk.js",
    "2f03b48d799dfe2022cb65ebeef841148500046f": "/29.b0225544b1ee4935f5a5.chunk.js",
    "cf7057980d68ef514366686441bab123ab9c114d": "/30.b0229c47695f74a841d1.chunk.js",
    "bfdf3f849130c427101e6cf2da337283972e299c": "/31.189e3c8e7d7a60bd03b6.chunk.js",
    "0528b3ef40434de277a943fe1152e2de0fc56bdb": "/32.5cc91ad33ed9413fa4a5.chunk.js",
    "d4b961159ba4224ee9a001f1b7627178a655d87b": "/33.d4dee0db0d93a25508bb.chunk.js",
    "f4442cbf8b07bc59d37c1e340849e855c2e3b107": "/34.2ac416d6d7ea6fd97029.chunk.js",
    "777361425218c9328ddccce07c70758daf38ac77": "/35.e5ec92b078d10900a029.chunk.js",
    "96c1c91f84747d9e5e6ccab84da11463924db1d3": "/36.7521309cf2f6dd42d0e5.chunk.js",
    "256882b26646791eda3887839dbd4e2f0f5ede9e": "/37.e04f57a30078e432bac9.chunk.js",
    "b4b5048efa9f6bf34549d0efd44acdf0bb3d300f": "/38.1fb6092b05583d4316ad.chunk.js",
    "675dcc5c5dfb9a5598c78ab38d91ff461ef9ee2e": "/39.4836059101009f2fc949.chunk.js",
    "400f8bc385b0252e0f36425c0af4cbd1eaf542f5": "/40.c5cdfcb3bdeb3defd021.chunk.js",
    "8aacaedd75e624b566311cb0cdbb2ee5b7207eda": "/41.7e7e4f7f7198e9b4bd12.chunk.js",
    "45a070846c7a1184b84762456303e661815514a4": "/42.34e0b4a3840bf695734b.chunk.js",
    "90dc5d638080c93a7bf1c7302d59135429bbf89a": "/43.49188a710da07271b797.chunk.js",
    "efdcd2b3ac32d9d3ccecc9f1ca93fcdd7449186d": "/44.eed71e6b8fb825932b23.chunk.js",
    "ba0226b3dd6bedbef2a59b79cd9056522b342ca7": "/45.ad557d5659c581bd1806.chunk.js",
    "c35e7608e47792dd07b1620e92793da43d87e750": "/46.a9e5d1cba81ba06bb12d.chunk.js",
    "5557c1e3991d94cae22b696138a403838bf68ec1": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "7/27/2021, 1:26:25 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/kathmandu-portal-client/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });